import psycopg2

con = psycopg2.connect(database="sashapar", user="sashapar", password="sashapar", host="127.0.0.1", port="5432")

print("Database opened successfully")
cur = con.cursor()
cur.execute(
  "SELECT * FROM numbers;"
)

rows = cur.fetchall()

print(rows)

con.close()


